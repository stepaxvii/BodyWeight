/* screen-boss.jsx — Босс месяца: tabs Текущий / История. Secondary page. */

const { useState: useStateB } = React;

const DAMAGERS = [
  { n: "Виктор", v: 18400, av: "titan" }, { n: "Марина", v: 16200, av: "phoenix" }, { n: "Вы · Алекс", v: 12400, you: true },
  { n: "Дэн", v: 9200, av: "kraken" }, { n: "Лена", v: 7100, av: "hydra" },
];
const HISTORY = [
  { n: "Снежный Волк", id: "blizzard-wolf", d: "Февраль", res: "defeated" },
  { n: "Тыквенный Король", id: "pumpkin-king", d: "Январь", res: "defeated" },
  { n: "Штормовой Левиафан", id: "storm-leviathan", d: "Декабрь", res: "expired" },
];
const fmtB = (n) => n.toLocaleString("ru-RU");

function BossBody({ onBack, avatar = "leviathan" }) {
  const { PixelIcon, GameAvatar, FillBar, SecHead, CountUp, BackHeader } = window;
  const [tab, setTab] = useStateB("current");

  return (
    <div className="screen__scroll view-enter">
      <BackHeader title="Босс месяца" onBack={onBack} />

      <div className="tabs">
        {[["current", "Текущий"], ["history", "История"]].map(([id, l]) => (
          <div key={id} className={"tab" + (tab === id ? " is-active" : "")} onClick={() => setTab(id)}>{l}</div>
        ))}
      </div>

      {tab === "current" && (
        <div className="view-enter" style={{ display: "flex", flexDirection: "column", gap: 12 }}>
          <section className="boss-hero">
            <GameAvatar id="frost-golem" kind="bosses" size={120} anim="b" />
            <div className="boss-hero__top">
              <span className="boss-hero__name">Frost Golem</span>
              <span className="status status--active">В битве</span>
            </div>
            <span className="boss-hero__period">1 марта — 31 марта</span>
            <div className="boss-hero__hpwrap">
              <FillBar value={62} max={100} segments={26} kind="hp" delay={300} />
              <div className="boss-hero__hprow"><span className="boss-hero__hp"><CountUp to={31000} /> HP</span><span style={{ color: "var(--muted)" }}>/ 50 000</span></div>
            </div>
            <p className="boss-hero__legend">Ледяной голем пробудился в горах. Каждая тренировка наносит ему урон — побеждайте сообща!</p>
          </section>

          <button className="btn btn--coral"><PixelIcon name="sword" size={16} color="#fff" /> Нанести урон тренировкой</button>

          <section>
            <SecHead title="Твой вклад" />
            <div className="contrib">
              <div className="contrib__i"><span className="contrib__v">{fmtB(12400)}</span><span className="contrib__l">урон</span></div>
              <div className="contrib__i"><span className="contrib__v">#3</span><span className="contrib__l">место</span></div>
              <div className="contrib__i"><span className="contrib__v">28</span><span className="contrib__l">ударов</span></div>
            </div>
            <div className="claim">
              <div className="claim__l"><span className="claim__coins">+250</span><span className="claim__t">монет ждут тебя</span><span className="claim__top">🏆 Топ-10</span></div>
              <button className="btn btn--gold btn--sm">Забрать</button>
            </div>
          </section>

          <section>
            <SecHead title="Топ по урону" />
            <div className="lb">
              {DAMAGERS.map((d, i) => (
                <div key={d.n} className={"lb-row" + (i < 3 ? " lb-row--" + (i + 1) : "") + (d.you ? " lb-row--you" : "")}>
                  <span className="lb-row__rank">#{i + 1}</span>
                  <GameAvatar id={d.you ? avatar : d.av} size={34} seed={i + 5} className="lb-row__av" />
                  <div className="lb-row__meta"><span className="lb-row__name">{d.n}{d.you && <span className="you-badge">ВЫ</span>}</span><span className="lb-row__sub">урон</span></div>
                  <span className="lb-row__xp">{fmtB(d.v)}</span>
                </div>
              ))}
            </div>
          </section>
        </div>
      )}

      {tab === "history" && (
        <div className="view-enter" style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          {HISTORY.map((h, i) => (
            <div key={i} className="hist">
              <GameAvatar id={h.id} kind="bosses" size={44} seed={i + 1} />
              <div className="hist__meta"><span className="hist__name">{h.n}</span><span className="hist__d">{h.d}</span></div>
              <span className={"status status--" + (h.res === "defeated" ? "active" : "finished")}>{h.res === "defeated" ? "Повержен" : "Не побеждён"}</span>
            </div>
          ))}
        </div>
      )}

      <div className="screen__pad"></div>
    </div>
  );
}

Object.assign(window, { BossBody });
