# PixelFit — Redesign Handoff (Stardew-cozy pixel theme)

Этот пакет — интерактивный прототип редизайна PixelFit. Он повторяет **те же страницы
и тот же функционал**, что и в действующем приложении, но в новом визуальном направлении
(«Bold Pop» в палитре Stardew Valley): тёплый пергамент, деревянные обводки, травяной
зелёный / небесно-голубой / янтарный / амбарно-красный, жёсткие пиксельные тени.

Прототип написан на **React + Babel в одном HTML** только ради быстрого предпросмотра.
Это НЕ требование к стеку — реальный проект остаётся на SvelteKit. Ниже — как перенести
визуал и токены в существующие компоненты.

---

## 1. Что в пакете

```
PixelFit App.html        — точка входа прототипа (открыть в браузере)
styles.css               — базовая раскладка экрана + тема (.variant-a = Stardew)
app.css                  — компоненты редизайна + слой анимаций
pixel-kit.jsx            — иконки (rects), GameAvatar, SegBar, Heatmap
ui.jsx                   — оболочка: TgBar, BottomNav, Tabs, BackHeader, CountUp, FillBar
proto.jsx                — роутинг между экранами + рамка телефона
screen-home.jsx          — Главная
screen-workout.jsx       — Тренировка (Программы/Мои/Избранное/Упражнения)
screen-challenges.jsx    — Челленджи
screen-leaderboard.jsx   — Рейтинг (подиум + список)
screen-friends.jsx       — Друзья (Друзья/Заявки/Поиск)
screen-achievements.jsx  — Достижения
screen-boss.jsx          — Босс месяца (Текущий/История)
screen-profile.jsx       — Профиль
screen-avatars.jsx       — Выбор героя (магазин аватаров)
sprites/avatars/*.svg    — 14 существующих + 5 НОВЫХ аватаров
sprites/bosses/*.svg     — спрайты боссов (для боссбара/страницы/истории)
```

> Данные в прототипе — заглушки (моки). Подставляйте реальные сторы/`api` при интеграции.

---

## 2. Дизайн-токены (палитра Stardew)

Замените значения существующих CSS-переменных в вашем `app.css` (`:root` / тема).
Слева — ваши текущие имена, справа — новые значения.

```css
/* поверхности */
--pixel-bg:        #e7cf9b;  /* фон страницы (пергамент-поле) */
--pixel-card:      #fbe8c4;  /* карточки/панели (тёплый крем, НЕ белый) */
--pixel-bg-dark:   #f0dca6;  /* вложенные плашки, треки баров */

/* контур и текст (дерево вместо чёрного) */
--border-color:    #5a3a1c;  /* основная обводка 3px */
--pixel-border:    #5a3a1c;
--text-primary:    #3a2718;  /* тёмно-коричневый, не чёрный */
--text-secondary:  #87694a;
--text-muted:      #b39a72;

/* акценты */
--pixel-accent:    #4d8fcc;  /* небесно-голубой: активные состояния, ссылки, hero */
--pixel-green:     #57a23f;  /* травяной: главное действие, успех, прогресс */
--pixel-yellow:    #f4c542;  /* золото: награды, стрик, подиум #1 */
--pixel-orange:    #f0b54a;  /* янтарь: монеты, плитки статов */
--pixel-red:       #c8463f;  /* амбарный красный: опасность, HP, danger */

/* тень — жёсткая, со смещением, цвет тёмного дерева */
--shadow-hard:     4px 4px 0 #4a2f18;
--radius:          0;        /* без скруглений */
--border-width:    3px;      /* жирная обводка везде */
```

**Шрифты.** Заголовки/цифры — «Silkscreen»; основной текст и мелкие подписи —
«Pixelify Sans» (читается мелким размером лучше, чем Press Start 2P). Можно оставить ваш
пиксельный шрифт для заголовков, но для подписей <11px переключитесь на Pixelify Sans.

**Правила формы:** обводка 3px цветом `--border-color`; тень `4px 4px 0` тёмным деревом;
радиус 0. Крупные блоки — цветовое блокирование: hero = голубой, главное действие = зелёное,
плитки статов = янтарные, опасность = красная.

---

## 3. Соответствие компонентов (прототип → ваши Svelte-компоненты)

| Прототип (класс/файл)             | Ваш компонент / место                         |
|-----------------------------------|-----------------------------------------------|
| `.cta` + `.quick` (screen-home)   | `.workout-card` + `.quick-record-btn`         |
| `.hero` (уровень+XP)              | `.progress-card` (Главная/Профиль)            |
| `.statrow`                        | `.stats-row`                                  |
| `.bossbar`                        | `BossBar.svelte`                              |
| `.heatmap` (Heatmap)              | `ActivityCalendar.svelte` (год) / `ActivityBarChart.svelte` |
| `.tabs` / `.tab`, `.pill`         | `PixelTabs.svelte` + чипы категорий            |
| `.podium`, `.lb-row`              | подиум + строки `leaderboard/+page`           |
| `.chal`                           | карточки `challenges/+page`                    |
| `.fr-row`, `.invite`, `.searchbar`| `friends/+page` (user-item / invite / поиск)   |
| `.achcard`                        | карточки `achievements/+page`                  |
| `.phead`, `.badges`, `.streakcard`, `.freeze`, `.acc` | `profile/+page` секции    |
| `.avpick` / `screen-avatars`      | `AvatarPicker.svelte`                          |
| `GameAvatar`                      | `PixelAvatar.svelte` (см. п.5 — анимация)      |

Разметка в прототипе намеренно повторяет порядок и состав блоков ваших страниц,
так что перенос — это в основном замена классов/токенов, а не переработка структуры.

---

## 4. Пять новых аватаров

Новые SVG лежат в `sprites/avatars/`:

```
solar-lion.svg     Солнечный Лев     (lvl 8,  350)
crystal-stag.svg   Хрустальный Олень (lvl 10, 450)
storm-eagle.svg    Штормовой Орёл    (lvl 14, 600)
void-serpent.svg   Бездонный Змей    (lvl 18, 900)
magma-golem.svg    Магма-Голем       (lvl 22, 1200)
```

Они нарисованы в том же стиле, что и существующие (32×32, тёмный фон, светящиеся глаза
с белым бликом, декоративные акценты), чтобы бесшовно встать в сетку.

**Как подключить в проект:**

1. Скопируйте 5 файлов в `static/sprites/avatars/`.
2. Добавьте id в тип в `src/lib/types`:
   ```ts
   export type AvatarId =
     | 'shadow-wolf' | /* ...существующие... */ | 'titan'
     | 'solar-lion' | 'crystal-stag' | 'storm-eagle' | 'void-serpent' | 'magma-golem';
   ```
3. Добавьте записи в `src/lib/data/avatars.ts` (`AVATARS`):
   ```ts
   { id: 'solar-lion',   name: 'Solar Lion',   name_ru: 'Солнечный Лев',     requiredLevel: 8,  price: 350 },
   { id: 'crystal-stag', name: 'Crystal Stag', name_ru: 'Хрустальный Олень', requiredLevel: 10, price: 450 },
   { id: 'storm-eagle',  name: 'Storm Eagle',  name_ru: 'Штормовой Орёл',    requiredLevel: 14, price: 600 },
   { id: 'void-serpent', name: 'Void Serpent', name_ru: 'Бездонный Змей',    requiredLevel: 18, price: 900 },
   { id: 'magma-golem',  name: 'Magma Golem',  name_ru: 'Магма-Голем',       requiredLevel: 22, price: 1200 },
   ```
4. Бэкенд: добавьте эти id в каталог покупаемых аватаров (по вашей схеме цен/уровней).

---

## 5. Анимация аватаров и боссов

Аватары и боссы — это ваши обычные SVG (`<img>`), оживлённые **CSS-анимацией ожидания**
(idle). Достаточно навесить одну из анимаций на `<img>` внутри `PixelAvatar.svelte`:

```css
@media (prefers-reduced-motion: no-preference) {
  .pixel-avatar img.idle-bob    { animation: avBobA 2.6s ease-in-out infinite; }
  .pixel-avatar img.idle-breath { animation: avBreathe 3s ease-in-out infinite; }
  .pixel-avatar img.idle-sway   { animation: avSway 3.4s ease-in-out infinite; transform-origin: center bottom; }
  .pixel-avatar img.idle-hop    { animation: avHop 2.4s ease-in-out infinite; transform-origin: center bottom; }
}
@keyframes avBobA   { 0%,100%{transform:translateY(0)} 50%{transform:translateY(-2px) scaleY(.97)} }
@keyframes avBreathe{ 0%,100%{transform:scale(1)} 50%{transform:scale(1.045)} }
@keyframes avSway   { 0%,100%{transform:rotate(-3deg)} 50%{transform:rotate(3deg)} }
@keyframes avHop    { 0%,66%,100%{transform:translateY(0) scaleY(1)} 80%{transform:translateY(-4px) scaleY(1.05)} 90%{transform:translateY(0) scaleY(.93)} }
```

Назначайте вариант детерминированно (например по индексу/хэшу id), чтобы сетка
аватаров «дышала» вразнобой. Для премиум-аватаров используется пульсирующая золотая
рамка (`.gav--ring::before` + `@keyframes ringPulse` в `app.css`).

> Покадровое моргание/движение частей тела не делалось намеренно: это потребовало бы
> переразметки каждого SVG (вынос глаз/ушей в отдельные группы). Idle-анимация целого
> спрайта даёт «живость» без вмешательства в исходный пиксель-арт. Если захотите моргание —
> правильный путь: инлайнить SVG и обернуть rect-ы глаз в `<g class="eyes">` с
> `animation: blink` (scaleY), у каждого спрайта свои координаты.

---

## 6. Прочий слой анимаций (по желанию)

В `app.css` есть «игровой» слой (секции *RICH ANIMATION* и *GAME-ENGINE JUICE*):
каскадное появление карточек/строк, рост столбцов графика, заполнение XP/HP-баров,
блик-проход по барам, намотка чисел (`CountUp`), мерцание стрика, вращение монет,
пульс золотого подиума, поп вкладок при выборе, squash-отклик карточек при нажатии,
тост-награда с искрами. Все эффекты обёрнуты в
`@media (prefers-reduced-motion: no-preference)` — при системной настройке «уменьшить
движение» интерфейс статичен.

---

## 7. Кавеаты интеграции

- **Данные** в прототипе — моки; источники истины — ваши `userStore`, `api`, сторы.
- **Масштабирование** (скрипт `fitStage` в HTML и рамка `.phone`) — только для предпросмотра;
  в Telegram Mini App контент занимает вьюпорт целиком, рамка не нужна.
- **Тач-таргеты** ≥44px, мелкие подписи переведены на Pixelify Sans для читаемости —
  сохраните это при переносе.
- **Иконки** в прототипе нарисованы из `<rect>` (pixel-kit). У вас уже есть `PixelIcon` —
  используйте свой набор, токены цветов те же.
- Прототип не трогает структуру роутов/навигации: таб-бар = Главная / Тренировка /
  Челленджи / Рейтинг / Профиль; Босс/Достижения/Друзья/Выбор героя — вторичные экраны.
```
