/* ui.jsx — shared shell, nav, tabs, animated primitives. Exports to window. */

const { useState, useEffect, useRef } = React;

/* Count-up number animation (respects reduced motion) */
function useCountUp(target, { duration = 900, deps = [] } = {}) {
  const [val, setVal] = useState(target);
  useEffect(() => {
    if (window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
      setVal(target); return;
    }
    let raf, start;
    const from = 0;
    const tick = (t) => {
      if (start == null) start = t;
      const p = Math.min(1, (t - start) / duration);
      const eased = 1 - Math.pow(1 - p, 3);
      setVal(from + (target - from) * eased);
      if (p < 1) raf = requestAnimationFrame(tick);
      else setVal(target);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, deps.length ? deps : [target]);
  return val;
}

function CountUp({ to, decimals = 0, suffix = "", prefix = "", format = true, dep }) {
  const v = useCountUp(to, { deps: [to, dep] });
  let n = decimals ? v.toFixed(decimals) : Math.round(v).toString();
  if (format && !decimals) n = Math.round(v).toLocaleString("ru-RU");
  return <>{prefix}{n}{suffix}</>;
}

/* Telegram bar */
function TgBar({ title = "PixelFit" }) {
  return (
    <div className="tgbar">
      <span className="tgbar__title">{title}</span>
      <span className="tgbar__dots"><i></i><i></i><i></i></span>
    </div>
  );
}

/* Segmented tabs */
function Tabs({ items, active, onChange }) {
  return (
    <div className="tabs">
      {items.map((it) => (
        <div key={it.id} className={"tab" + (active === it.id ? " is-active" : "")}
          onClick={() => onChange(it.id)}>{it.label}</div>
      ))}
    </div>
  );
}

/* Section heading */
function SecHead({ title, meta }) {
  return (
    <div className="sec-head">
      <span className="sec-head__t">{title}</span>
      {meta != null && <span className="sec-head__m">{meta}</span>}
    </div>
  );
}

/* Bottom nav — matches the real app routes */
const NAV = [
  { id: "home", icon: "home", label: "Главная" },
  { id: "workout", icon: "dumbbell", label: "Тренировка" },
  { id: "challenges", icon: "calendar", label: "Челленджи" },
  { id: "leaderboard", icon: "trophy", label: "Рейтинг" },
  { id: "profile", icon: "user", label: "Профиль" },
];
function BottomNav({ active, onNav }) {
  const { PixelIcon } = window;
  // secondary pages map back onto a nav root for active-state
  const rootOf = { boss: "home", achievements: "profile", friends: "profile" };
  const act = rootOf[active] || active;
  return (
    <nav className="nav">
      {NAV.map((n) => (
        <button key={n.id}
          className={"nav__item" + (act === n.id ? " is-active" : "")}
          onClick={() => onNav(n.id)}>
          <PixelIcon name={n.icon} size={18} />
          <span>{n.label}</span>
        </button>
      ))}
    </nav>
  );
}

/* Back header used on secondary pages */
function BackHeader({ title, onBack, action }) {
  const { PixelIcon } = window;
  return (
    <header className="shead">
      <div className="shead__l">
        <button className="iconbtn" onClick={onBack} aria-label="Назад"><PixelIcon name="arrowleft" size={16} /></button>
        <span className="shead__t">{title}</span>
      </div>
      {action || null}
    </header>
  );
}

/* Animated XP/HP segmented bar that fills on mount/change */
function FillBar({ value, max, segments = 24, kind = "xp", delay = 350 }) {
  const { SegBar } = window;
  const [shown, setShown] = useState(0);
  useEffect(() => {
    if (window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
      setShown(value); return;
    }
    setShown(0);
    const t = setTimeout(() => setShown(value), delay);
    return () => clearTimeout(t);
  }, [value, max]);
  return <SegBar value={shown} max={max} segments={segments} kind={kind} />;
}

Object.assign(window, { useCountUp, CountUp, TgBar, Tabs, SecHead, BottomNav, BackHeader, FillBar });
