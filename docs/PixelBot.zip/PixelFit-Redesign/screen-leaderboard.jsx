/* screen-leaderboard.jsx — Рейтинг: podium + list, tabs Все/Неделя/Друзья. */

const { useState: useStateL } = React;

const LB = [
  { n: "Виктор", lvl: 41, xp: 84200, st: 23, av: "titan" },
  { n: "Марина", lvl: 39, xp: 79100, st: 18, av: "phoenix" },
  { n: "Дэн", lvl: 37, xp: 71500, st: 9, av: "kraken" },
  { n: "Лена", lvl: 33, xp: 60800, st: 14, av: "hydra" },
  { n: "Костя", lvl: 31, xp: 55200, st: 6, av: "cerberus" },
  { n: "Артём", lvl: 28, xp: 47000, st: 11, av: "griffin" },
  { n: "Вы · Алекс", lvl: 24, xp: 18200, st: 12, you: true },
];
const fmt = (n) => n.toLocaleString("ru-RU");

function LeaderboardBody({ avatar = "leviathan" }) {
  const { PixelIcon, GameAvatar, Tabs } = window;
  const [tab, setTab] = useStateL("global");
  const isFriends = tab === "friends";
  const list = isFriends ? LB.filter((e) => e.you || e.lvl < 40) : LB;
  const podium = !isFriends ? [list[1], list[0], list[2]] : [];
  const rest = isFriends ? list : list.slice(3);

  return (
    <div className="screen__scroll view-enter">
      <header className="shead shead--center"><span className="shead__t">Рейтинг</span></header>

      <Tabs active={tab} onChange={setTab} items={[
        { id: "global", label: "Все" }, { id: "weekly", label: "Неделя" }, { id: "friends", label: "Друзья" },
      ]} />

      {!isFriends && (
        <div className="podium view-enter">
          {podium.map((e, idx) => {
            const place = idx === 1 ? 1 : idx === 0 ? 2 : 3;
            return (
              <div key={e.n} className={"podium__i podium__i--" + place}>
                {place === 1 && <span className="podium__crown"><PixelIcon name="crown" size={18} color="#b8860b" /></span>}
                <GameAvatar id={e.you ? avatar : e.av} size={place === 1 ? 54 : 42} seed={idx + 2} ring={place === 1} />
                <span className="podium__name">{e.n}</span>
                <span className="podium__xp">{fmt(e.xp)} XP</span>
                <span className="podium__rank">{place}</span>
              </div>
            );
          })}
        </div>
      )}

      <div className="lb">
        {rest.map((e) => {
          const rank = LB.indexOf(e) + 1;
          return (
            <div key={e.n} className={"lb-row" + (e.you ? " lb-row--you" : "")}>
              <span className="lb-row__rank">{rank <= 3 ? <PixelIcon name="trophy" size={13} color={rank === 1 ? "#b8860b" : "var(--muted)"} /> : null}#{rank}</span>
              <GameAvatar id={e.you ? avatar : e.av} size={34} seed={rank + 3} className="lb-row__av" />
              <div className="lb-row__meta">
                <span className="lb-row__name">{e.n}{e.you && <span className="you-badge">ВЫ</span>}</span>
                <span className="lb-row__sub">Ур.{e.lvl}</span>
              </div>
              <div className="lb-row__right">
                <span className="lb-row__xp">{fmt(e.xp)}<span className="lb-row__xpl">XP</span></span>
              </div>
              <span className="lb-row__streak"><PixelIcon name="flame" size={12} color="var(--gold)" />{e.st}</span>
            </div>
          );
        })}
      </div>

      <div className="screen__pad"></div>
    </div>
  );
}

Object.assign(window, { LeaderboardBody });
