/* pixel-kit.jsx — rects-only pixel icons, sprite placeholders, heatmap.
   All shapes are unit squares (pixel art) drawn as <rect>. Exports to window. */

// ── Icon data: rows of '1' (filled) / '0' (empty). Mostly 8×8. ────────────
const PX_ICONS = {
  bolt: [
    "00001110",
    "00011100",
    "00111000",
    "01111110",
    "00011110",
    "00111000",
    "01110000",
    "11100000",
  ],
  flame: [
    "00011000",
    "00011100",
    "00111100",
    "00111110",
    "01111110",
    "01101110",
    "01111110",
    "00111100",
  ],
  coin: [
    "00111100",
    "01111110",
    "11100111",
    "11011011",
    "11011011",
    "11100111",
    "01111110",
    "00111100",
  ],
  dumbbell: [
    "00000000",
    "11000011",
    "11000011",
    "11111111",
    "11111111",
    "11000011",
    "11000011",
    "00000000",
  ],
  play: [
    "11000000",
    "11100000",
    "11110000",
    "11111000",
    "11111000",
    "11110000",
    "11100000",
    "11000000",
  ],
  plus: [
    "00011000",
    "00011000",
    "00011000",
    "11111111",
    "11111111",
    "00011000",
    "00011000",
    "00011000",
  ],
  bell: [
    "00011000",
    "00111100",
    "00111100",
    "01111110",
    "01111110",
    "11111111",
    "00000000",
    "00011000",
  ],
  trophy: [
    "01111110",
    "11111111",
    "11111111",
    "01111110",
    "00111100",
    "00011000",
    "00111100",
    "01111110",
  ],
  level: [
    "00011000",
    "00111100",
    "01111110",
    "11111111",
    "00011000",
    "00111100",
    "01111110",
    "11111111",
  ],
  skull: [
    "00111100",
    "01111110",
    "11011011",
    "11011011",
    "11111111",
    "01111110",
    "01011010",
    "01011010",
  ],
  heart: [
    "01100110",
    "11111111",
    "11111111",
    "11111111",
    "01111110",
    "00111100",
    "00011000",
    "00000000",
  ],
  users: [
    "01100110",
    "01100110",
    "00000000",
    "11100111",
    "11111111",
    "11111111",
    "11111111",
    "00000000",
  ],
  medal: [
    "01000010",
    "01100110",
    "00111100",
    "00011000",
    "00111100",
    "01111110",
    "01111110",
    "00111100",
  ],
  check: [
    "00000001",
    "00000011",
    "00000110",
    "11001100",
    "11011000",
    "01110000",
    "00110000",
    "00000000",
  ],
  target: [
    "00111100",
    "01000010",
    "10011001",
    "10100101",
    "10100101",
    "10011001",
    "01000010",
    "00111100",
  ],
  calendar: [
    "01000010",
    "11111111",
    "10000001",
    "10110101",
    "10000001",
    "10101011",
    "10000001",
    "11111111",
  ],
  home: [
    "00011000",
    "00111100",
    "01111110",
    "11111111",
    "11011011",
    "11011011",
    "11011011",
    "11011011",
  ],
  chevron: [
    "00010000",
    "00111000",
    "01111100",
    "11111110",
    "00000000",
    "00000000",
    "00000000",
    "00000000",
  ],
  close: [
    "11000011",
    "11100111",
    "01111110",
    "00111100",
    "00111100",
    "01111110",
    "11100111",
    "11000011",
  ],
  crown: [
    "00000000",
    "10100101",
    "11100111",
    "11111111",
    "11111111",
    "11111111",
    "11111111",
    "00000000",
  ],
  star: [
    "00011000",
    "00011000",
    "11111111",
    "01111110",
    "00111100",
    "01111110",
    "01100110",
    "11000011",
  ],
  user: [
    "00111100",
    "01111110",
    "01111110",
    "00111100",
    "00000000",
    "01111110",
    "11111111",
    "11111111",
  ],
  lock: [
    "00111100",
    "01100110",
    "01100110",
    "11111111",
    "11011011",
    "11011011",
    "11111111",
    "00000000",
  ],
  sword: [
    "00000111",
    "00001110",
    "00011100",
    "00111000",
    "01110000",
    "11110000",
    "11100000",
    "11000000",
  ],
  arrowup: [
    "00011000",
    "00111100",
    "01111110",
    "11111111",
    "00111100",
    "00111100",
    "00111100",
    "00000000",
  ],
  arrowdown: [
    "00000000",
    "00111100",
    "00111100",
    "00111100",
    "11111111",
    "01111110",
    "00111100",
    "00011000",
  ],
  gift: [
    "00011000",
    "01111110",
    "11111111",
    "00111100",
    "00111100",
    "00111100",
    "00111100",
    "00000000",
  ],
  gear: [
    "00111100",
    "01011010",
    "11111111",
    "11100111",
    "11100111",
    "11111111",
    "01011010",
    "00111100",
  ],
  edit: [
    "00000111",
    "00001110",
    "00011100",
    "00111000",
    "01110000",
    "11110000",
    "11100000",
    "00000000",
  ],
  clock: [
    "00111100",
    "01000010",
    "10011001",
    "10011001",
    "10011111",
    "10000001",
    "01000010",
    "00111100",
  ],
  arrowleft: [
    "00010000",
    "00110000",
    "01110000",
    "11111111",
    "11111111",
    "01110000",
    "00110000",
    "00010000",
  ],
  search: [
    "01110000",
    "10001000",
    "10001000",
    "10001000",
    "01110100",
    "00000110",
    "00000011",
    "00000001",
  ],
  warning: [
    "00011000",
    "00011000",
    "00111100",
    "00111100",
    "01111110",
    "01100110",
    "11111111",
    "00011000",
  ],
  share: [
    "00000110",
    "00001111",
    "00011000",
    "01111000",
    "11001100",
    "11000110",
    "01100011",
    "00111100",
  ],
  mail: [
    "11111111",
    "11000011",
    "10100101",
    "10011001",
    "10000001",
    "10000001",
    "11111111",
    "00000000",
  ],
};

function PixelIcon({ name, size = 16, color = "currentColor", className = "", style = {} }) {
  const grid = PX_ICONS[name] || PX_ICONS.star;
  const rows = grid.length, cols = grid[0].length;
  const rects = [];
  for (let y = 0; y < rows; y++) {
    for (let x = 0; x < cols; x++) {
      if (grid[y][x] === "1") rects.push(<rect key={x + "_" + y} x={x} y={y} width="1.02" height="1.02" />);
    }
  }
  return (
    <svg className={"pico " + className} width={size} height={size} viewBox={`0 0 ${cols} ${rows}`}
      fill={color} style={{ display: "block", shapeRendering: "crispEdges", ...style }}>
      {rects}
    </svg>
  );
}

// ── Sprite placeholder: clearly a placeholder for future redraw. ──────────
function PixelSprite({ label = "SPRITE", size = 48, tone = "var(--accent)", className = "", style = {} }) {
  return (
    <div className={"pixel-sprite " + className}
      style={{ width: size, height: size, "--sprite-tone": tone, ...style }}>
      <span className="pixel-sprite__tag">{label}</span>
    </div>
  );
}

// ── Animated pixel avatar (Stardew-style "junimo" blob) ───────────────────
const AV_TONES = ["#5fa233", "#4d8fcc", "#c8463f", "#8a5fc0", "#f0b54a", "#3fae9a", "#e0772e", "#d36fa0"];
const AV_BODY = [
  "0000000000",
  "0011111100",
  "0111111110",
  "0111111110",
  "0111111110",
  "0111111110",
  "0111111110",
  "0011111100",
  "0000000000",
  "0000000000",
];
function PixelAvatar({ size = 40, seed = 0, tone, className = "", style = {} }) {
  const ink = "#3a2718";
  const col = tone || AV_TONES[((seed % AV_TONES.length) + AV_TONES.length) % AV_TONES.length];
  const rects = [];
  for (let y = 0; y < AV_BODY.length; y++)
    for (let x = 0; x < AV_BODY[0].length; x++)
      if (AV_BODY[y][x] === "1") rects.push(<rect key={x + "_" + y} x={x} y={y} width="1.02" height="1.02" fill={col} />);
  const delay = ((seed % 5) * 0.3).toFixed(2) + "s";
  return (
    <div className={"pxav " + className} style={{ width: size, height: size, ...style }}>
      <svg viewBox="0 0 10 10" width="100%" height="100%" style={{ display: "block", shapeRendering: "crispEdges" }}>
        <g className="pxav__body" style={{ animationDelay: delay }}>
          {rects}
          <rect className="pxav__shine" x="3" y="2" width="1.02" height="1.02" fill="#fff" opacity="0.45" />
          <g className="pxav__eyes" style={{ animationDelay: delay }}>
            <rect x="3" y="3.4" width="1.05" height="2.1" fill={ink} />
            <rect x="6" y="3.4" width="1.05" height="2.1" fill={ink} />
          </g>
          <rect x="4" y="6" width="2.1" height="0.9" fill={ink} opacity="0.6" />
        </g>
      </svg>
    </div>
  );
}

// ── Animated game avatar/boss sprite (real SVG + idle motion) ─────────────
const GAV_ANIMS = ["a", "b", "c", "d"];
function GameAvatar({ id, kind = "avatars", size = 44, seed = 0, anim, ring = false, frame = true, className = "", style = {} }) {
  const a = anim || GAV_ANIMS[((seed % 4) + 4) % 4];
  const delay = ((seed % 5) * 0.25).toFixed(2) + "s";
  return (
    <div className={"gav " + (frame ? "gav--frame " : "") + (ring ? "gav--ring " : "") + className}
      style={{ width: size, height: size, ...style }}>
      <img className={"gav__img gav__img--" + a} src={"sprites/" + kind + "/" + id + ".svg"}
        alt={id} draggable="false" style={{ animationDelay: delay }} />
    </div>
  );
}

// ── Segmented bar: pixel-style progress / HP. ─────────────────────────────
function SegBar({ value = 0, max = 100, segments = 20, kind = "xp", className = "" }) {
  const ratio = Math.max(0, Math.min(1, max ? value / max : 0));
  const filled = Math.round(ratio * segments);
  const cells = [];
  for (let i = 0; i < segments; i++) {
    cells.push(
      <span key={i} className={"seg" + (i < filled ? " seg--on" : "")}
        style={{ "--i": i, "--n": segments }} />
    );
  }
  return <div className={`segbar segbar--${kind} ${className}`} role="progressbar">{cells}</div>;
}

// ── Activity heatmap: weeks × 7 grid of intensity cells (GitHub-style). ────
function Heatmap({ weeks = 18, seed = 7, className = "" }) {
  // deterministic pseudo-random intensities 0..4
  const cells = [];
  let s = seed * 9301 + 49297;
  const rnd = () => { s = (s * 9301 + 49297) % 233280; return s / 233280; };
  for (let w = 0; w < weeks; w++) {
    const col = [];
    for (let d = 0; d < 7; d++) {
      const r = rnd();
      let lvl = 0;
      if (r > 0.55) lvl = 1;
      if (r > 0.72) lvl = 2;
      if (r > 0.85) lvl = 3;
      if (r > 0.94) lvl = 4;
      // taper the most recent partial week
      if (w === weeks - 1 && d > 3) lvl = 0;
      col.push(<span key={d} className="hm-cell" data-lvl={lvl} />);
    }
    cells.push(<div key={w} className="hm-col">{col}</div>);
  }
  return <div className={"heatmap " + className}>{cells}</div>;
}

Object.assign(window, { PixelIcon, PixelSprite, PixelAvatar, GameAvatar, SegBar, Heatmap });
