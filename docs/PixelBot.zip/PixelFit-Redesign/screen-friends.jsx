/* screen-friends.jsx — Друзья: tabs Друзья / Заявки / Поиск. Secondary page. */

const { useState: useStateF } = React;

const FRIENDS = [
  { n: "Марина", lvl: 39, st: 18, av: "phoenix" },
  { n: "Дэн", lvl: 37, st: 9, av: "kraken" },
  { n: "Лена", lvl: 33, st: 14, av: "hydra" },
  { n: "Костя", lvl: 31, st: 6, av: "cerberus" },
];
const REQUESTS = [{ n: "Игорь", lvl: 17, av: "fire-fox" }];
const FOUND = [
  { n: "alex_fit", sub: "Алексей", lvl: 22, status: "none", av: "iron-bear" },
  { n: "iron_kate", sub: "Катя", lvl: 30, status: "pending", av: "griffin" },
  { n: "dmitry", sub: "Дмитрий", lvl: 12, status: "accepted", av: "night-panther" },
];

function FriendsBody({ onBack }) {
  const { PixelIcon, GameAvatar, Tabs, BackHeader } = window;
  const [tab, setTab] = useStateF("friends");

  return (
    <div className="screen__scroll view-enter">
      <BackHeader title="Друзья" onBack={onBack} />

      <Tabs active={tab} onChange={setTab} items={[
        { id: "friends", label: `Друзья ${FRIENDS.length}` },
        { id: "requests", label: `Заявки ${REQUESTS.length}` },
        { id: "search", label: "Поиск" },
      ]} />

      {tab === "friends" && (
        <div className="view-enter" style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          {FRIENDS.map((f) => (
            <div key={f.n} className="fr-row">
              <GameAvatar id={f.av} size={40} seed={f.lvl} />
              <div className="fr-row__meta">
                <span className="fr-row__name">{f.n}</span>
                <span className="fr-row__status">Ур.{f.lvl} · <PixelIcon name="flame" size={10} color="var(--gold)" style={{ display: "inline-block", verticalAlign: "-1px" }} /> {f.st}</span>
              </div>
              <button className="fr-row__x" aria-label="Удалить"><PixelIcon name="close" size={11} color="var(--muted)" /></button>
            </div>
          ))}
        </div>
      )}

      {tab === "requests" && (
        <div className="view-enter" style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          {REQUESTS.map((r) => (
            <div key={r.n} className="fr-row">
              <GameAvatar id={r.av} size={40} seed={r.lvl} />
              <div className="fr-row__meta"><span className="fr-row__name">{r.n}</span><span className="fr-row__status">Ур.{r.lvl}</span></div>
              <div style={{ display: "flex", gap: 6 }}>
                <button className="btn btn--primary btn--sm">Принять</button>
                <button className="fr-row__x" aria-label="Отклонить"><PixelIcon name="close" size={11} color="var(--muted)" /></button>
              </div>
            </div>
          ))}
        </div>
      )}

      {tab === "search" && (
        <div className="view-enter" style={{ display: "flex", flexDirection: "column", gap: 12 }}>
          <div className="invite">
            <div className="invite__l"><PixelIcon name="share" size={14} color="var(--accent)" /><span>Пригласить друга</span></div>
            <button className="btn btn--sm"><PixelIcon name="share" size={12} /> Поделиться</button>
          </div>
          <div className="searchbar">
            <PixelIcon name="search" size={14} color="var(--muted)" />
            <input className="searchbar__in" placeholder="Введите username..." />
          </div>
          <span className="search-hint">Найдено: {FOUND.length}</span>
          {FOUND.map((u) => (
            <div key={u.n} className="fr-row">
              <GameAvatar id={u.av} size={40} seed={u.lvl} />
              <div className="fr-row__meta"><span className="fr-row__name">{u.n}</span><span className="fr-row__status">{u.sub} · Ур.{u.lvl}</span></div>
              {u.status === "accepted" ? <span className="status-badge accepted">Друг</span>
                : u.status === "pending" ? <span className="status-badge pending">Отправлено</span>
                : <button className="btn btn--primary btn--sm">Добавить</button>}
            </div>
          ))}
        </div>
      )}

      <div className="screen__pad"></div>
    </div>
  );
}

Object.assign(window, { FriendsBody });
