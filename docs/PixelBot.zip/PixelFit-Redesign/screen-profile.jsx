/* screen-profile.jsx — Profile, matching the real app's blocks. */

const { useState: useStateP2 } = React;

const RANGES = [
  { id: "week", label: "7 дней", n: 7 },
  { id: "2w", label: "14 дней", n: 14 },
  { id: "month", label: "30 дней", n: 30 },
  { id: "3m", label: "90 дней", n: 90 },
];
const BADGES = ["play", "flame", "dumbbell", "skull", "trophy", "coin", "medal", "star"];

function ActivityBars({ n, seed = 5 }) {
  let s = seed * 7919 + 13;
  const rnd = () => { s = (s * 9301 + 49297) % 233280; return s / 233280; };
  const count = Math.min(n, 30);
  const bars = Array.from({ length: count }, () => Math.max(6, Math.round(rnd() * 100)));
  return (
    <div className="bars">
      {bars.map((h, i) => <span key={i} className="bars__b" style={{ "--h": h + "%", "--bi": i }}></span>)}
    </div>
  );
}

function ProfileBody({ onNav, avatar = "leviathan" }) {
  const { PixelIcon, PixelSprite, GameAvatar, FillBar, SecHead, CountUp } = window;
  const [range, setRange] = useStateP2("week");
  const r = RANGES.find((x) => x.id === range);

  return (
    <div className="screen__scroll view-enter">
      {/* header */}
      <header className="phead">
        <button className="phead__avbtn" aria-label="Сменить аватар" onClick={() => onNav("avatars")}>
          <GameAvatar id={avatar} size={66} seed={3} className="phead__av" />
          <span className="phead__edit"><PixelIcon name="gear" size={10} color="#fff" /></span>
        </button>
        <div className="phead__id">
          <span className="phead__name">Алекс</span>
          <span className="phead__title">Пиксельный воин</span>
          <div className="phead__lvlrow">
            <span className="phead__lvl">Ур.24</span>
            <div className="phead__xp">
              <FillBar value={1340} max={2000} segments={16} kind="xp" />
              <span className="phead__xptext">1 340/2 000 XP</span>
            </div>
          </div>
        </div>
      </header>

      {/* activity chart */}
      <section>
        <SecHead title="Активность" />
        <div className="ranges">
          {RANGES.map((x) => (
            <button key={x.id} className={"range" + (range === x.id ? " is-active" : "")} onClick={() => setRange(x.id)}>{x.label}</button>
          ))}
        </div>
        <div className="card-plain"><ActivityBars n={r.n} seed={r.n} /></div>
      </section>

      {/* stats row */}
      <div className="statrow statrow--4">
        <div className="statrow__i"><PixelIcon name="bolt" size={15} color="var(--accent)" /><span className="statrow__v"><CountUp to={18200} /></span></div>
        <div className="statrow__i"><PixelIcon name="coin" size={15} color="var(--gold)" /><span className="statrow__v"><CountUp to={486} /></span></div>
        <div className="statrow__i"><PixelIcon name="flame" size={15} color="var(--danger)" /><span className="statrow__v">12</span></div>
        <div className="statrow__i"><PixelIcon name="trophy" size={15} color="#b8860b" /><span className="statrow__v">8</span></div>
      </div>

      {/* badges */}
      <section className="badges">
        <div className="badges__head">
          <PixelIcon name="trophy" size={15} color="var(--accent)" />
          <span className="badges__t">Значки</span>
          <span className="badges__c">8/24</span>
        </div>
        <div className="badges__grid">
          {BADGES.map((b, i) => (
            <div key={i} className="badge"><PixelIcon name={b} size={16} color="var(--text)" /></div>
          ))}
          <button className="badge badge--more" onClick={() => onNav("achievements")}>+16</button>
        </div>
      </section>

      {/* streak + freeze */}
      <section style={{ gap: 10 }}>
        <div className="streakcard">
          <div className="streakcard__l">
            <PixelIcon name="flame" size={22} color="var(--danger)" className="flicker" />
            <div className="streakcard__nums"><span className="streakcard__cur">12 дней</span><span className="streakcard__max">Рекорд: 41</span></div>
          </div>
          <div className="streakcard__vis">{Array.from({ length: 7 }, (_, i) => <span key={i} className={"sd" + (i < 7 ? " on" : "")}></span>)}</div>
        </div>
        <div className="freeze">
          <div className="freeze__l">
            <span className="freeze__ic">🧊</span>
            <div className="freeze__nums"><span className="freeze__t">Заморозки: 1/2</span><span className="freeze__h">Спасают серию за пропущенный день</span></div>
          </div>
          <button className="freeze__buy">100 <PixelIcon name="coin" size={12} color="#b8860b" style={{ display: "inline-block", verticalAlign: "-1px" }} /></button>
        </div>
      </section>

      {/* friends link */}
      <button className="linkcard" onClick={() => onNav("friends")}>
        <PixelIcon name="users" size={16} color="var(--accent)" /><span>Друзья</span>
        <PixelIcon name="chevron" size={12} color="var(--muted)" className="linkcard__chev" />
      </button>

      {/* account */}
      <section>
        <SecHead title="Аккаунт" />
        <div className="acc">
          <div className="acc__row"><span className="acc__l">Telegram</span><span className="acc__v">ID: 123456789</span></div>
        </div>
        <button className="btn" style={{ justifyContent: "flex-start" }}>Привязать Telegram</button>
      </section>

      <div className="screen__pad"></div>
    </div>
  );
}

Object.assign(window, { ProfileBody });
