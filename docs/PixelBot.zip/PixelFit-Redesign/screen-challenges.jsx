/* screen-challenges.jsx — Челленджи: tabs Идут/Скоро/Завершены/Мои. */

const { useState: useStateC } = React;

const CH = {
  active: [
    { t: "10 000 отжиманий за месяц", st: "active", d: "1 мар — 31 мар", p: 1240, ex: 3, by: "coach_max", member: true },
    { t: "Марафон планки", st: "active", d: "5 мар — 19 мар", p: 412, ex: 1, by: "irina" },
  ],
  upcoming: [{ t: "Весенний забег", st: "upcoming", d: "1 апр — 30 апр", p: 88, ex: 5, by: "pixelfit" }],
  finished: [{ t: "Зимний челлендж", st: "finished", d: "1 фев — 28 фев", p: 2310, ex: 4, by: "coach_max" }],
  mine: [{ t: "10 000 отжиманий за месяц", st: "active", d: "1 мар — 31 мар", p: 1240, ex: 3, by: "coach_max", member: true }],
};
const ST = { active: "Идёт", upcoming: "Скоро", finished: "Завершён" };

function ChallengesBody() {
  const { PixelIcon, Tabs } = window;
  const [tab, setTab] = useStateC("active");
  const items = CH[tab] || [];

  return (
    <div className="screen__scroll view-enter">
      <header className="shead">
        <span className="shead__t">Челленджи</span>
        <button className="iconbtn iconbtn--accent" aria-label="Создать"><PixelIcon name="plus" size={16} color="#fff" /></button>
      </header>

      <Tabs active={tab} onChange={setTab} items={[
        { id: "active", label: "Идут" }, { id: "upcoming", label: "Скоро" },
        { id: "finished", label: "Завершены" }, { id: "mine", label: "Мои" },
      ]} />

      <div className="view-enter" style={{ display: "flex", flexDirection: "column", gap: 10 }}>
        {items.length === 0 && <div className="empty">Нет челленджей</div>}
        {items.map((c, i) => (
          <div key={i} className="chal">
            <div className="chal__top">
              <span className="chal__name">{c.t}</span>
              <span className={"status status--" + c.st}>{ST[c.st]}</span>
            </div>
            <span className="chal__dates">{c.d}</span>
            <div className="chal__foot">
              <div className="chal__stats">
                <span className="chal__stat"><b>{c.p.toLocaleString("ru-RU")}</b> участников</span>
                <span className="chal__stat"><b>{c.ex}</b> упражн.</span>
              </div>
              <span className="chal__by">от @{c.by}</span>
            </div>
            {c.member && <span className="chal__member"><PixelIcon name="check" size={10} color="#fff" /> Ты участвуешь</span>}
          </div>
        ))}
      </div>

      <div className="screen__pad"></div>
    </div>
  );
}

Object.assign(window, { ChallengesBody });
