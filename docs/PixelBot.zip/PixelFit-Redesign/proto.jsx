/* proto.jsx — phone frame, nav routing across all real pages. */

const { useState: useStatePr } = React;

function App() {
  const { TgBar, BottomNav, HomeBody, WorkoutBody, ChallengesBody, LeaderboardBody,
    ProfileBody, FriendsBody, AchievementsBody, BossBody, AvatarsBody } = window;
  const [view, setView] = useStatePr("home");
  const [avatar, setAvatar] = useStatePr("leviathan");
  const onNav = (id) => setView(id);
  const back = () => setView(view === "boss" ? "home" : "profile");

  return (
    <div className="phone">
      <div className="screen variant-a">
        <div className="screen__vign" aria-hidden="true"></div>
        <TgBar title="PixelFit" />
        {view === "home" && <HomeBody key="home" onNav={onNav} avatar={avatar} />}
        {view === "workout" && <WorkoutBody key="workout" />}
        {view === "challenges" && <ChallengesBody key="challenges" />}
        {view === "leaderboard" && <LeaderboardBody key="leaderboard" avatar={avatar} />}
        {view === "profile" && <ProfileBody key="profile" onNav={onNav} avatar={avatar} />}
        {view === "friends" && <FriendsBody key="friends" onBack={back} />}
        {view === "achievements" && <AchievementsBody key="achievements" onBack={back} />}
        {view === "boss" && <BossBody key="boss" onBack={back} avatar={avatar} />}
        {view === "avatars" && <AvatarsBody key="avatars" onBack={back} current={avatar} onPick={setAvatar} />}
        <BottomNav active={view} onNav={onNav} />
      </div>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
