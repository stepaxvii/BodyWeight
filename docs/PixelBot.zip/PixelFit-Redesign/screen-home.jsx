/* screen-home.jsx — Home, matching the real app's blocks & functionality. */

const { useState: useStateH } = React;

const HOME_NOTIFS = [
  { ic: "trophy", t: "Новое достижение!", m: "«100 тренировок» открыто", unread: true },
  { ic: "flame", t: "Серия в опасности", m: "Не пропусти тренировку сегодня", unread: true },
  { ic: "user", t: "Заявка в друзья", m: "Игорь хочет добавить вас", unread: true },
  { ic: "level", t: "Повышение уровня", m: "Вы достигли Ур. 24", unread: false },
];

function HomeBody({ onNav, avatar = "leviathan" }) {
  const { PixelIcon, PixelSprite, GameAvatar, FillBar, Heatmap, SecHead, CountUp } = window;
  const [notifOpen, setNotifOpen] = useStateH(false);
  const [reward, setReward] = useStateH(false);
  const unread = HOME_NOTIFS.filter((n) => n.unread).length;

  const quickSave = () => { setReward(true); setTimeout(() => setReward(false), 2600); };

  return (
    <div className="screen__scroll view-enter">
      {/* header: greeting + level badge / notifications */}
      <header className="hdr">
        <div className="hdr__id">
          <GameAvatar id={avatar} size={44} seed={1} />
          <div className="hdr__meta">
            <span className="hdr__hi">Добрый вечер,</span>
            <span className="hdr__name">Алекс</span>
            <span className="lvl-badge"><PixelIcon name="level" size={10} color="var(--accent)" /> Ур.24</span>
          </div>
        </div>
        <div className="notif">
          <button className={"bell" + (unread ? " has" : "")} onClick={() => setNotifOpen(!notifOpen)} aria-label="Уведомления">
            <PixelIcon name="bell" size={18} />
            {unread > 0 && <span className="bell__dot">{unread}</span>}
          </button>
          {notifOpen && (
            <>
              <div className="notif__overlay" onClick={() => setNotifOpen(false)}></div>
              <div className="notif__drop">
                <div className="notif__head"><span>Уведомления</span>
                  <button className="notif__close" onClick={() => setNotifOpen(false)}><PixelIcon name="close" size={10} /></button>
                </div>
                <div className="notif__list">
                  {HOME_NOTIFS.map((n, i) => (
                    <div key={i} className={"notif__item" + (n.unread ? " unread" : "")}>
                      <span className="notif__ic"><PixelIcon name={n.ic} size={14} color="var(--accent)" /></span>
                      <div className="notif__txt"><span className="notif__t">{n.t}</span><span className="notif__m">{n.m}</span></div>
                    </div>
                  ))}
                </div>
                <button className="notif__foot" onClick={() => { setNotifOpen(false); onNav("friends"); }}>Перейти к друзьям</button>
              </div>
            </>
          )}
        </div>
      </header>

      {/* primary action: start workout */}
      <a className="cta" href="#" onClick={(e) => { e.preventDefault(); onNav("workout"); }}>
        <span className="cta__glow" aria-hidden="true"></span>
        <span className="cta__ic"><PixelIcon name="dumbbell" size={22} /></span>
        <span className="cta__txt">
          <span className="cta__t">Начать тренировку</span>
          <span className="cta__s">Выбери программу или упражнения</span>
        </span>
        <span className="cta__go"><PixelIcon name="play" size={16} /></span>
      </a>
      <button className="quick" onClick={quickSave}><PixelIcon name="plus" size={12} /><span>Быстрая запись</span></button>

      {/* monthly boss bar (links to boss page) */}
      <button className="bossbar" onClick={() => onNav("boss")}>
        <GameAvatar id="frost-golem" kind="bosses" size={46} seed={0} className="bossbar__img" />
        <div className="bossbar__body">
          <div className="bossbar__head"><span className="bossbar__name">Frost Golem</span><span className="bossbar__pct">62%</span></div>
          <div className="hp-track"><span className="hp-fill" style={{ width: "62%" }}></span></div>
          <span className="bossbar__hp">31 000 / 50 000 HP</span>
        </div>
      </button>

      {/* level + XP progress card (cobalt hero) */}
      <section className="hero">
        <div className="hero__row">
          <div className="hero__lvl">
            <span className="hero__lvlnum">24</span>
            <span className="hero__lvllbl">Уровень</span>
          </div>
          <div className="hero__xp">
            <FillBar value={1340} max={2000} segments={20} kind="xp" />
            <span className="hero__xplbl"><CountUp to={1340} />/2 000 XP до следующего</span>
          </div>
        </div>
      </section>

      {/* stats row: XP / streak / coins */}
      <div className="statrow">
        <div className="statrow__i"><PixelIcon name="bolt" size={16} color="var(--accent)" /><div><span className="statrow__v"><CountUp to={18200} /></span><span className="statrow__l">XP</span></div></div>
        <span className="statrow__div"></span>
        <div className="statrow__i"><PixelIcon name="flame" size={16} color="var(--danger)" className="flicker" /><div><span className="statrow__v">12</span><span className="statrow__l">Серия</span></div></div>
        <span className="statrow__div"></span>
        <div className="statrow__i"><PixelIcon name="coin" size={16} color="var(--gold)" className="spin-slow" /><div><span className="statrow__v"><CountUp to={486} /></span><span className="statrow__l">Монеты</span></div></div>
      </div>

      {/* this week */}
      <section>
        <SecHead title="Эта неделя" />
        <div className="week__row">
          <div className="week__stat"><PixelIcon name="dumbbell" size={20} color="#2ea043" /><span className="week__v">4</span><span className="week__l">тренировок</span></div>
          <div className="week__stat"><PixelIcon name="bolt" size={20} color="var(--accent)" /><span className="week__v">340</span><span className="week__l">XP за неделю</span></div>
        </div>
      </section>

      {/* activity calendar (year) */}
      <section className="activity">
        <SecHead title="Активность" meta="2026" />
        <Heatmap weeks={26} seed={7} />
        <div className="activity__legend">
          <span>меньше</span>
          <span className="hm-cell" data-lvl={0}></span><span className="hm-cell" data-lvl={1}></span>
          <span className="hm-cell" data-lvl={2}></span><span className="hm-cell" data-lvl={3}></span>
          <span className="hm-cell" data-lvl={4}></span>
          <span>больше</span>
        </div>
      </section>

      <div className="screen__pad"></div>

      {reward && (
        <div className="toast-wrap"><div className="toast">
          <span className="toast__burst" aria-hidden="true"></span>
          <PixelIcon name="bolt" size={22} color="#fff" />
          <div className="toast__txt"><span className="toast__t">+120 XP</span><span className="toast__s">Записано!</span></div>
          <span className="toast__coin"><PixelIcon name="coin" size={16} color="#ffcf2e" /> +24</span>
        </div></div>
      )}
    </div>
  );
}

Object.assign(window, { HomeBody });
