/* screen-avatars.jsx — Avatar picker / shop. Secondary page from profile. */

const { useState: useStateAv } = React;

// real app data + 5 new avatars
const AVATARS = [
  { id: "shadow-wolf", name: "Теневой Волк", lvl: 1, price: 0 },
  { id: "iron-bear", name: "Железный Медведь", lvl: 1, price: 0 },
  { id: "fire-fox", name: "Огненный Лис", lvl: 1, price: 0 },
  { id: "night-panther", name: "Ночная Пантера", lvl: 1, price: 0 },
  { id: "phoenix", name: "Феникс", lvl: 3, price: 100 },
  { id: "solar-lion", name: "Солнечный Лев", lvl: 8, price: 350, neu: true },
  { id: "griffin", name: "Грифон", lvl: 5, price: 200 },
  { id: "crystal-stag", name: "Хрустальный Олень", lvl: 10, price: 450, neu: true },
  { id: "cerberus", name: "Цербер", lvl: 7, price: 300 },
  { id: "thunder-fang", name: "Громовой Клык", lvl: 7, price: 350 },
  { id: "cyber-ape", name: "Кибер-Примат", lvl: 7, price: 375 },
  { id: "storm-eagle", name: "Штормовой Орёл", lvl: 14, price: 600, neu: true },
  { id: "hydra", name: "Гидра", lvl: 10, price: 400 },
  { id: "minotaur", name: "Минотавр", lvl: 12, price: 500 },
  { id: "void-serpent", name: "Бездонный Змей", lvl: 18, price: 900, neu: true },
  { id: "kraken", name: "Кракен", lvl: 15, price: 750 },
  { id: "leviathan", name: "Левиафан", lvl: 20, price: 1000 },
  { id: "magma-golem", name: "Магма-Голем", lvl: 22, price: 1200, neu: true },
  { id: "titan", name: "Титан", lvl: 25, price: 1500 },
];
const MY_LEVEL = 24, MY_COINS = 486;
const OWNED = new Set(["shadow-wolf", "iron-bear", "fire-fox", "night-panther", "phoenix", "griffin", "leviathan"]);

function AvatarsBody({ onBack, current = "leviathan", onPick }) {
  const { PixelIcon, GameAvatar, BackHeader } = window;
  const [sel, setSel] = useStateAv(current);

  const stateOf = (a) => {
    if (MY_LEVEL < a.lvl) return "locked";
    if (a.id === current) return "current";
    if (a.price === 0 || OWNED.has(a.id)) return "owned";
    return "buy";
  };

  return (
    <div className="screen__scroll view-enter">
      <BackHeader title="Выбор героя" onBack={onBack}
        action={<span className="avcoins" style={{ fontSize: 14 }}><PixelIcon name="coin" size={13} color="#8a6a1e" /> {MY_COINS}</span>} />

      <div className="avpick">
        {AVATARS.map((a, i) => {
          const st = stateOf(a);
          const locked = st === "locked";
          return (
            <button key={a.id} className={"avopt" + (sel === a.id ? " is-sel" : "") + (locked ? " is-locked" : "")}
              disabled={locked} onClick={() => !locked && setSel(a.id)}>
              {a.neu && <span className="avnew">NEW</span>}
              <span className="avopt__av">
                <GameAvatar id={a.id} size={58} seed={i} ring={a.id === current} />
                {locked && <span className="avopt__lock"><PixelIcon name="lock" size={18} color="#fff" /></span>}
              </span>
              <span className="avopt__name">{a.name}</span>
              {st === "current" && <span className="avopt__meta cur">Текущий</span>}
              {st === "owned" && <span className="avopt__meta free">Доступен</span>}
              {st === "buy" && <span className="avopt__meta price"><PixelIcon name="coin" size={11} color="#8a6a1e" /> {a.price}</span>}
              {st === "locked" && <span className="avopt__meta">Ур.{a.lvl}</span>}
            </button>
          );
        })}
      </div>

      <div className="avpick-foot">
        <span className="avcoins"><PixelIcon name="coin" size={15} color="#8a6a1e" /> {MY_COINS}</span>
        <button className="btn btn--primary" style={{ width: "auto" }}
          disabled={sel === current}
          onClick={() => { onPick && onPick(sel); onBack && onBack(); }}>
          {sel === current ? "Выбрано" : OWNED.has(sel) || AVATARS.find((x) => x.id === sel).price === 0 ? "Выбрать" : "Купить"}
        </button>
      </div>

      <div className="screen__pad"></div>
    </div>
  );
}

Object.assign(window, { AvatarsBody });
