/* screen-workout.jsx — Workout hub: Программы / Мои / Избранное / Упражнения. */

const { useState: useStateW } = React;

const ROUTINE_CATS = [
  { id: "morning", label: "Утро" },
  { id: "day", label: "День" },
  { id: "evening", label: "Вечер" },
  { id: "full", label: "Всё тело" },
];
const ROUTINES = {
  morning: [
    { name: "Лёгкий разогрев", n: 5, min: 12, diff: 1, xp: 80 },
    { name: "Зарядка чемпиона", n: 7, min: 18, diff: 2, xp: 140 },
  ],
  day: [
    { name: "Кор и пресс", n: 6, min: 20, diff: 2, xp: 160 },
    { name: "Взрывная сила", n: 8, min: 25, diff: 3, xp: 220 },
  ],
  evening: [{ name: "Растяжка и баланс", n: 6, min: 15, diff: 1, xp: 90 }],
  full: [{ name: "Полная прокачка", n: 10, min: 35, diff: 3, xp: 320 }],
};
const EX_CATS = ["Все", "Грудь", "Спина", "Ноги", "Пресс", "Руки"];
const EXERCISES = [
  { name: "Отжимания", cat: "Грудь", diff: 1, eq: "Без снаряжения" },
  { name: "Подтягивания", cat: "Спина", diff: 3, eq: "Турник" },
  { name: "Приседания", cat: "Ноги", diff: 1, eq: "Без снаряжения" },
  { name: "Планка", cat: "Пресс", diff: 2, eq: "Без снаряжения" },
  { name: "Берпи", cat: "Ноги", diff: 3, eq: "Без снаряжения" },
  { name: "Выпады", cat: "Ноги", diff: 2, eq: "Без снаряжения" },
];

function Diff({ n }) {
  return <span className="diff">{[1, 2, 3].map((i) => <span key={i} className={"diff__d" + (i <= n ? " on" : "")}></span>)}</span>;
}

function WorkoutBody() {
  const { PixelIcon, PixelSprite, Tabs } = window;
  const [tab, setTab] = useStateW("routines");
  const [rcat, setRcat] = useStateW("morning");
  const [ecat, setEcat] = useStateW("Все");

  return (
    <div className="screen__scroll view-enter">
      <header className="shead"><span className="shead__t">Тренировка</span>
        <span className="chip"><PixelIcon name="bolt" size={11} color="var(--accent)" /> Серия 12</span>
      </header>

      <Tabs active={tab} onChange={setTab} items={[
        { id: "routines", label: "Программы" }, { id: "mine", label: "Мои" },
        { id: "fav", label: "Избранное" }, { id: "exercises", label: "Упражнения" },
      ]} />

      {tab === "routines" && (
        <div className="view-enter" style={{ display: "flex", flexDirection: "column", gap: 12 }}>
          <div className="chips-row">
            {ROUTINE_CATS.map((c) => (
              <button key={c.id} className={"pill" + (rcat === c.id ? " is-active" : "")} onClick={() => setRcat(c.id)}>{c.label}</button>
            ))}
          </div>
          {(ROUTINES[rcat] || []).map((r) => (
            <div key={r.name} className="rcard">
              <PixelSprite label="PROG" size={48} tone="var(--accent)" />
              <div className="rcard__meta">
                <span className="rcard__name">{r.name}</span>
                <span className="rcard__sub">{r.n} упражнений · ~{r.min} мин</span>
                <div className="rcard__foot"><Diff n={r.diff} /><span className="rcard__xp"><PixelIcon name="bolt" size={11} color="var(--accent)" /> +{r.xp} XP</span></div>
              </div>
              <button className="rcard__go" aria-label="Начать"><PixelIcon name="play" size={16} color="#fff" /></button>
            </div>
          ))}
        </div>
      )}

      {tab === "mine" && (
        <div className="view-enter" style={{ display: "flex", flexDirection: "column", gap: 12 }}>
          <button className="btn btn--primary"><PixelIcon name="plus" size={14} color="#fff" /> Создать программу</button>
          <div className="rcard">
            <PixelSprite label="MINE" size={48} tone="#2ea043" />
            <div className="rcard__meta">
              <span className="rcard__name">Моя программа №1</span>
              <span className="rcard__sub">4 упражнения · ~14 мин</span>
              <div className="rcard__foot"><Diff n={2} /><span className="chip" style={{ minHeight: 24, padding: "3px 7px" }}>изменить</span></div>
            </div>
            <button className="rcard__go" aria-label="Начать"><PixelIcon name="play" size={16} color="#fff" /></button>
          </div>
        </div>
      )}

      {tab === "fav" && (
        <div className="view-enter" style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          {EXERCISES.slice(0, 3).map((e) => (
            <div key={e.name} className="exrow">
              <PixelSprite label="EX" size={40} tone="var(--accent)" />
              <div className="exrow__meta"><span className="exrow__name">{e.name}</span><span className="exrow__sub">{e.cat} · {e.eq}</span></div>
              <Diff n={e.diff} />
            </div>
          ))}
        </div>
      )}

      {tab === "exercises" && (
        <div className="view-enter" style={{ display: "flex", flexDirection: "column", gap: 12 }}>
          <div className="searchbar">
            <PixelIcon name="search" size={14} color="var(--muted)" />
            <input className="searchbar__in" placeholder="Поиск упражнения..." />
            <button className="searchbar__filter"><PixelIcon name="gear" size={14} /></button>
          </div>
          <div className="chips-row">
            {EX_CATS.map((c) => (
              <button key={c} className={"pill" + (ecat === c ? " is-active" : "")} onClick={() => setEcat(c)}>{c}</button>
            ))}
          </div>
          {EXERCISES.filter((e) => ecat === "Все" || e.cat === ecat).map((e) => (
            <div key={e.name} className="exrow">
              <PixelSprite label="EX" size={40} tone="var(--accent)" />
              <div className="exrow__meta"><span className="exrow__name">{e.name}</span><span className="exrow__sub">{e.cat} · {e.eq}</span></div>
              <Diff n={e.diff} />
            </div>
          ))}
        </div>
      )}

      <div className="screen__pad"></div>
    </div>
  );
}

Object.assign(window, { WorkoutBody });
