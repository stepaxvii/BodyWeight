/* screen-achievements.jsx — Достижения: tabs Все/Открыто/Закрыто. Secondary page. */

const { useState: useStateA } = React;

const ACHS = [
  { ic: "play", name: "Первый шаг", desc: "Заверши первую тренировку", un: true, xp: 50, co: 10, date: "12.01.2026" },
  { ic: "flame", name: "Неделя огня", desc: "Серия 7 дней подряд", un: true, xp: 100, co: 25, date: "20.01.2026" },
  { ic: "dumbbell", name: "Сотня", desc: "100 тренировок", un: true, xp: 300, co: 80, date: "03.03.2026" },
  { ic: "skull", name: "Победитель босса", desc: "Победи босса месяца", un: true, xp: 250, co: 60, date: "28.02.2026" },
  { ic: "flame", name: "Несгораемый", desc: "Серия 30 дней", un: false, xp: 400, co: 120, prog: 12, goal: 30 },
  { ic: "trophy", name: "Чемпион", desc: "Топ-3 в рейтинге", un: false, xp: 500, co: 150, prog: 14, goal: 3 },
  { ic: "clock", name: "Ранняя пташка", desc: "10 тренировок до 8 утра", un: false, xp: 150, co: 40, prog: 4, goal: 10 },
  { ic: "coin", name: "Меценат", desc: "Накопи 1000 монет", un: false, xp: 200, co: 0, prog: 486, goal: 1000 },
];

function AchievementsBody({ onBack }) {
  const { PixelIcon, FillBar, BackHeader } = window;
  const [tab, setTab] = useStateA("all");
  const un = ACHS.filter((a) => a.un).length;
  const items = ACHS.filter((a) => tab === "all" || (tab === "unlocked" ? a.un : !a.un));

  return (
    <div className="screen__scroll view-enter">
      <BackHeader title="Достижения" onBack={onBack}
        action={<span className="ach-count">{un} / {ACHS.length}</span>} />

      <div className="tabs">
        {[["all", "Все"], ["unlocked", "Открыто"], ["locked", "Закрыто"]].map(([id, l]) => (
          <div key={id} className={"tab" + (tab === id ? " is-active" : "")} onClick={() => setTab(id)}>{l}</div>
        ))}
      </div>

      <div className="view-enter" style={{ display: "flex", flexDirection: "column", gap: 10 }}>
        {items.map((a, i) => (
          <div key={i} className={"achcard" + (a.un ? " is-un" : " is-locked")}>
            <div className="achcard__icwrap">
              <PixelIcon name={a.un ? a.ic : "lock"} size={24} color={a.un ? "var(--text)" : "var(--dim)"} />
            </div>
            <div className="achcard__body">
              <span className="achcard__name">{a.name}</span>
              <span className="achcard__desc">{a.desc}</span>
              {!a.un && a.prog != null && (
                <div className="achcard__prog">
                  <FillBar value={a.prog} max={a.goal} segments={14} kind="xp" delay={250} />
                  <span className="achcard__progt">{a.prog.toLocaleString("ru-RU")} / {a.goal.toLocaleString("ru-RU")}</span>
                </div>
              )}
              <div className="achcard__rew">
                <span className="achcard__r"><PixelIcon name="bolt" size={11} color={a.un ? "var(--accent)" : "var(--muted)"} /> +{a.xp} XP</span>
                {a.co > 0 && <span className="achcard__r"><PixelIcon name="coin" size={11} color={a.un ? "var(--gold)" : "var(--muted)"} /> +{a.co}</span>}
                {a.un && <span className="achcard__date">{a.date}</span>}
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="screen__pad"></div>
    </div>
  );
}

Object.assign(window, { AchievementsBody });
